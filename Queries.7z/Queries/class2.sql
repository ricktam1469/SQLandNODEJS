select *
from sales.SalesOrderHeader

select * from sales.SalesOrderDetail

select p.*,soh.orderdate
from production.Product p
join sales.SalesOrderDetail sod
	on p.ProductID=sod.ProductID
join sales.SalesOrderHeader soh
	on sod.SalesOrderID=soh.SalesOrderID
where soh.OrderDate=(
select min(orderdate) from sales.SalesOrderHeader
)



select * from
sales.SpecialOfferProduct

select p.*
from production.Product p
JOIN sales.SpecialOfferProduct so
ON p.ProductID=so.ProductID;


select p.*
from production.Product p
LEFT JOIN sales.SpecialOfferProduct so
ON p.ProductID=so.productID
where so.SpecialOfferID IS NULL

select p.*
from Production.Product p
where NOT EXISTS
(
select 1 from
sales.SpecialOfferProduct sop
where sop.ProductID=p.ProductID
)

--select distinct color from Production.Product where weight=( select max(weight) from Production.Product
--order by max(weight) desc)

select c.customerID
from sales.Customer c
join sales.SalesOrderHeader soh
	on c.CustomerID=soh.CustomerID
join sales.SalesOrderDetail sod
	on sod.SalesOrderID=soh.SalesOrderID
join Production.Product p
	on p.ProductID=sod.ProductID
where soh.OrderDate=(
select min(orderdate) 
from sales.SalesOrderHeader sohI
where sohI.CustomerID=c.CustomerID
)




)
