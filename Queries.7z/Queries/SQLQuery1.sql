Create Table Sales.MonthlyRollUp(
ProductId INT,
Year INT,
MONTH INT, 
Qty INT
)

MERGE Sales.MonthlyRollUp target
USING
(
	select sod.ProductId, MIN(DATEPART(year,soh.OrderDate)) as year,MIN(DATEPART(month,soh.OrderDate)) as month,SUM(sod.OrderQty) as qtty
	From Sales.SalesOrderDetail sod
	JOIN Sales.SalesOrderHeader soh
	ON sod.SalesOrderId=soh.SalesOrderId
	Where soh.OrderDate>='2007-08-01' AND soh.OrderDate<'2007-08-02'
	GROUP BY sod.ProductId

)src
ON target.productId=src.productId
When matched
then Update
Qty=Qty+src.qtty
when not matched by target
then Insert(productId,year,month,qty)
values(src.productId,src.year,src.month.src.qty);



