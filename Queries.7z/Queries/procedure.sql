--Write a Procedure supplying name information from the Person.Person table and accepting a filter for the first name. 
--Alter the above Store Procedure to supply Default Values if user does not enter any value

USE AdventureWorks2012
GO

IF EXISTS
(
SELECT 1
FROM sys.procedures
WHERE name='spFilterByFirstName'
)
BEGIN 
	DROP PROCEDURE spFilterByFirstName
END
GO

CREATE PROCEDURE spFilterByFirstName
@param NVARCHAR(30) 
AS
SELECT FirstName,LastName
FROM Person.Person 
WHERE FirstName LIKE @param + '%'
GO

ALTER PROC spFilterByFirstName
@param NVARCHAR(30) ='S'
AS
SELECT FirstName,LastName
FROM Person.Person 
WHERE FirstName LIKE @param + '%'

EXEC spFilterByFirstName 'T' ;
GO
