DROP TABLE  Sales.MonthlyRollup
WITH ABC AS(SELECT ROW_NUMBER() OVER (ORDER BY ListPrice desc) Number,ListPrice
FROM PRODUCTION.Product
WHERE ListPrice IS NOT NULL
)
SELECT * FROM ABC WHERE Number between 20 and 30
Create table Sales.MonthlyRollup
(
ProductID int NOT NULL,
Year int,
month int,
Quantity int
)


MERGE Sales.MonthlyRollup target
USING
(
Select SOD.ProductID,MIN(DATEPART(year,SOH.OrderDate)) as year,MIN(DATEPART(MONTH,SOH.OrderDate)) as MONTH,sum(sod.OrderQty) as qty
from Sales.SalesOrderDetail SOD
JOIN Sales.SalesOrderHeader SOH
	ON SOH.SalesOrderId=Sod.SalesOrderID
WHERE SOH.OrderDate >='2007-08-02' AND SOH.OrderDate <'2007-08-03'
GROUP BY SOD.ProductID
) src
on target.ProductID=src.ProductID
WHEN MATCHED THEN
UPDATE SET target.Quantity=target.Quantity+src.qty
WHEN NOT MATCHED BY TARGET
THEN
INSERT (ProductID,year,month,Quantity)
VALUES(src.ProductID,src.Year,src.Month,src.qty);


select *
from  Sales.MonthlyRollup