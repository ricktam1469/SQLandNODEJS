SELECT COUNT(*) FROM Sales.SalesPerson;
SET STATISTICS IO ON
SELECT firstname,lastname 
FROM Person.Person
WHERE firstname like('B%');

SELECT Person.Person.FirstName, Person.Person.LastName, HumanResources.Employee.JobTitle
FROM Person.Person INNER JOIN
 HumanResources.Employee ON Person.Person.BusinessEntityID = HumanResources.Employee.BusinessEntityID
 WHERE HumanResources.Employee.JobTitle='Design Engineer' OR 
 HumanResources.Employee.JobTitle='Tool Designer' OR
 HumanResources.Employee.JobTitle='Marketing Assistant';

<!--select FirstName, LastName from HumanResources.Employee where JobTitle in ('Design Engineer','Tool Designer','Marketing Assistant')
-->

select top 1 name,color,max(weight) from Production.Product
group by name,color
order by max(weight) desc

 SELECT TOP(1) Name,Color,Weight
 FROM Production.Product
 ORDER BY Weight DESC;

 SELECT Name,Color 
 FROM Production.Product
 WHERE Weight=(SELECT MAX(Weight) FROM Production.Product)

 SELECT ISNULL(MaxQTY,0.0),Description 
 FROM Sales.SpecialOffer
 
 SELECT ISNULL(MaxQTY,0.0) RickMaxQty,Description 
 FROM Sales.SpecialOffer

 SELECT AVG(Sales.CurrencyRate.AverageRate) 
 FROM Sales.CurrencyRate
 WHERE FromCurrencyCode='USD' AND
 ToCurrencyCode='GBP' AND 
 DATEPART(year,CurrencyRateDate)=2005;

 SELECT FirstName,LastName,ROW_NUMBER() OVER () AS 'RK'
 FROM Person.Person
 WHERE FirstName LIKE ('%ss%');

 SELECT ROW_NUMBER() OVER (ORDER BY FirstName) 
 AS 'RickRowNumber', FirstName, LastName from Person.Person where FirstName like '%ss%' 


 --ques1 part 9
 --q9


 DECLARE @ID int
  select @ID=BusinessEntityID from Person.Person where FirstName='Ruth' AND LastName='Ellerbrock' AND PersonType ='EM'
  select @ID
  EXEC dbo.uspGetEmployeeManagers @ID


 EXEC dbo.uspGetEmployeeManagers 49

WITH mngrLevel AS 
(
    SELECT
        p.FirstName ,
        p.LastName ,
        e.OrganizationLevel,
        e.OrganizationNode
    FROM
        HumanResources.Employee e
    INNER JOIN 
        person.person p ON e.BusinessEntityID = p.BusinessEntityID
    WHERE
        p.FirstName = 'Ruth'
        AND p.LastName = 'Ellerbrock'
)
SELECT 
    p.FirstName, 
    p.LastName,
    e.OrganizationLevel,
    CAST(e.OrganizationNode AS VARCHAR(20)) AS 'OrgNodeString'
FROM 
    HumanResources.Employee e
INNER JOIN 
    person.person p ON e.BusinessEntityID = p.BusinessEntityID
INNER JOIN
    mngrLevel a ON a.OrganizationNode.IsDescendantOf(e.OrganizationNode) = 1;


 SELECT  Person.Person.BusinessEntityID, Person.Person.FirstName, Person.Person.MiddleName, Person.Person.LastName, 
 HumanResources.EmployeePayHistory.Rate,HumanResources.Employee.OrganizationLevel, HumanResources.Employee.JobTitle
 FROM  HumanResources.Employee 
	JOIN  HumanResources.EmployeePayHistory 
	ON HumanResources.Employee.BusinessEntityID = HumanResources.EmployeePayHistory.BusinessEntityID 
	JOIN Person.Person 
	ON HumanResources.Employee.BusinessEntityID = Person.Person.BusinessEntityID
	where Person.person.BusinessEntityID<49 
	order by Person.person.BusinessEntityID asc;



	--ques 1 part 10
	SELECT ProductID,Quantity
FROM Production.ProductInventory
         order by Quantity desc;


		 select top 10 ProductID from [Production].[ProductInventory]
group by ProductID
order by sum(Quantity) desc

select top 1 productId,dbo.ufnGetStock(ProductId) from Production.Product order by dbo.ufnGetStock(ProductId) desc

select productId,dbo.ufnGetStock(ProductId) from Production.Product
where dbo.ufnGetStock(ProductId) IN( select MAX(dbo.ufnGetStock(ProductId)) from Production.Product)

select top 1 dbo.ufnGetStock(ProductId) from Production.Product
order by dbo.ufnGetStock(ProductId) desc







