-- Q1
WITH Customers AS
(
	SELECT DISTINCT C.CustomerID,
	(
		SELECT ISNULL(SUM(SOD.LineTotal), 0)
		FROM Sales.Customer CInner
		JOIN Sales.SalesOrderHeader SOH
			ON CInner.CustomerID = SOH.CustomerID
		JOIN Sales.SalesOrderDetail SOD
			ON SOH.SalesOrderID = SOD.SalesOrderID
		WHERE CInner.CustomerID = C.CustomerID
	) AS Purchase
	FROM Sales.Customer C
), RankedCustomers AS
(
	SELECT *, ROW_NUMBER() OVER (ORDER BY Purchase DESC) AS Position
	FROM Customers
), TopCustomers AS
(
	SELECT *
	FROM RankedCustomers
	WHERE Position <= 100
), TopCustomersProducts AS
(
	SELECT DISTINCT TC.CustomerID, P.ProductID, SUM(SOD.OrderQty) Quantity
	FROM TopCustomers TC
	JOIN Sales.SalesOrderHeader SOH
		ON TC.CustomerID = SOH.CustomerID
	JOIN Sales.SalesOrderDetail SOD
		ON SOH.SalesOrderID = SOD.SalesOrderID
	JOIN Production.Product P
		ON SOD.ProductID = P.ProductID
	GROUP BY TC.CustomerID, P.ProductID
), TopCustomersBestProducts AS
(
	SELECT *, ROW_NUMBER() OVER (PARTITION BY CustomerID ORDER BY Quantity DESC) AS Position
	FROM TopCustomersProducts
)
SELECT DISTINCT TCBP.CustomerID, P.FirstName, Prd.ProductID, Prd.Name, Prd.Color, Prd.Weight
FROM TopCustomersBestProducts TCBP
JOIN Production.Product Prd
	ON TCBP.ProductID = Prd.ProductID
JOIN Sales.Customer SC
	ON TCBP.CustomerID = SC.CustomerID
JOIN Person.Person P
	ON SC.PersonID = P.BusinessEntityID
WHERE Position <= 5
ORDER BY TCBP.CustomerID

-- Q2
WITH Products AS
(
	SELECT P.ProductID, 
	(
		SELECT ISNULL(SUM(SOD.OrderQty), 0)
		FROM Production.Product PInner
		JOIN Sales.SalesOrderDetail SOD
			ON PInner.ProductID = SOD.ProductID
		WHERE PInner.ProductID = P.ProductID
	) AS Quantity
	FROM Production.Product P
), RankedProducts AS
(
	SELECT *, ROW_NUMBER() OVER (ORDER BY Quantity DESC) Position
	FROM Products
), TopProducts AS
(
	SELECT * 
	FROM RankedProducts
	WHERE Position <= 100
), TopProductsCustomers AS
(
	SELECT TP.ProductID, SC.CustomerID, SUM(SOD.OrderQty) AS Quantity
	FROM TopProducts TP
	JOIN Sales.SalesOrderDetail SOD
		ON TP.ProductID = SOD.ProductID
	JOIN Sales.SalesOrderHeader SOH
		ON SOD.SalesOrderID = SOH.SalesOrderID
	JOIN Sales.Customer SC
		ON SOH.CustomerID = SC.CustomerID
	GROUP BY TP.ProductID, SC.CustomerID
), TopProductsBestCustomers AS
(
	SELECT *, ROW_NUMBER() OVER (PARTITION BY ProductID ORDER BY Quantity DESC) AS Position
	FROM TopProductsCustomers
)
SELECT TPBC.CustomerID, P.FirstName, Prd.ProductID, Prd.Name, Prd.Color, Prd.Weight
FROM TopProductsBestCustomers TPBC
JOIN Production.Product Prd
	ON TPBC.ProductID = Prd.ProductID
JOIN Sales.Customer SC
	ON TPBC.CustomerID = SC.CustomerID
JOIN Person.Person P
	ON SC.PersonID = P.BusinessEntityID
WHERE Position <= 5
ORDER BY TPBC.ProductID

-- Q3
SELECT ProductID, Name, Color, Weight, 
CASE 
WHEN Weight IS NULL THEN 'No Weight'
WHEN Weight < 500 THEN 'Light'
WHEN Weight < 1000 THEN 'Heavy'
ELSE 'Very heavy'
END AS 'Classification'
FROM Production.Product

-- Q4
SELECT DISTINCT C.CustomerID, C.AccountNumber, Prs.FirstName, P.ProductID, P.Name, SOD.LineTotal
FROM Sales.Customer C
JOIN Sales.SalesOrderHeader SOH
	ON C.CustomerID = SOH.CustomerID
JOIN Sales.SalesOrderDetail SOD
	ON SOH.SalesOrderID = SOD.SalesOrderID
JOIN Production.Product P
	ON SOD.ProductID = P.ProductID
JOIN Person.Person Prs
	ON C.PersonID = Prs.BusinessEntityID
WHERE SOD.LineTotal = 
(
	SELECT MAX(LineTotal)
	FROM Sales.Customer CInner
	JOIN Sales.SalesOrderHeader SOH
		ON CInner.CustomerID = SOH.CustomerID
	JOIN Sales.SalesOrderDetail SOD
		ON SOH.SalesOrderID = SOD.SalesOrderID
	JOIN Production.Product P
		ON SOD.ProductID = P.ProductID
	WHERE CInner.CustomerID = C.CustomerID
)
