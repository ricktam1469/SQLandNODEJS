--Create a function that takes as inputs a SalesOrderID, a Currency Code, and a date, 
--and returns a table of all the SalesOrderDetail rows for that Sales Order including Quantity,
-- ProductID, UnitPrice, and the unit price converted to the target currency based on the end of day r
-- ate for the date provided. Exchange rates can be found in the Sales.CurrencyRate table. ( Use AdventureWorks)



IF EXISTS
(
SELECT  1
     FROM    dbo.sysobjects
	 where name='fnGetDetail'
)
BEGIN 
	DROP FUNCTION fnGetDetail
END
GO



CREATE FUNCTION dbo.fnGetDetail
(@SalesOrderID AS int,@ToCurrencyCode AS nvarchar(max),@CurrencyRateDate AS DATETIME)
RETURNS @Reports TABLE
(
Quantity int  ,
ProductID int,
UnitPrice int  ,
unitPriceDay int 
)
AS
BEGIN

INSERT INTO @Reports
SELECT OrderQty,ProductID,UnitPrice,(SELECT UnitPrice*EndOfDayRate FROM Sales.CurrencyRate WHERE (CurrencyRateDate=@CurrencyRateDate AND ToCurrencyCode=@ToCurrencyCode))
FROM Sales.SalesOrderDetail
WHERE SalesOrderID = @SalesOrderID;

RETURN;
END
GO

SELECT *
FROM dbo.fnGetDetail(
43659,
'EUR',
'2005-07-05 00:00:00.000'
)

