select distinct e.firstname,e.jobtitle
from HumanResources.Employee2 e
join Person.Person p
on p.BusinessEntityID=e.BusinessEntityID


CREATE TABLE HumanResources.Employee2
(
  EmployeeID int NOT NULL,
  ManagerID int NULL REFERENCES HumanResources.Employee2(EmployeeID),
  JobTitle nvarchar(50) NOT NULL,
  LastName nvarchar(50) NOT NULL,
  FirstName nvarchar(50) NOT NULL,
    CONSTRAINT PK_Employee2_EmployeeID PRIMARY KEY CLUSTERED (EmployeeID ASC)
);

INSERT INTO HumanResources.Employee2(EmployeeID,ManagerID,JobTitle,LastName,FirstName)
VALUES
  (1, NULL, 'CEO','Smith', 'Hunter'),
  (2, 1, 'CFO', 'Jones', 'Drew'),
  (3, 1, 'COO','Lenzy','Sheila'),
  (4, 1, 'CTO', 'Huntington', 'Karla'),
  (5, 4, 'VP of Engineering', 'Gutierrez', 'Ron'),
  (8, 5, 'VP of Engineering', 'Gutierrez', 'Ron'),
  (9, 5, 'Software Engineer', 'Bray', 'Marky'),
  (10 ,5, 'Data Architect', 'Cheechov', 'Robert'),
  (11 ,5, 'Software Engineer', 'Gale', 'Sue'),
  (6, 4, 'VP of Professional Services', 'Cross', 'Gary'),
  (7, 4, 'VP of Security','Lebowski','Jeff');

select * from HumanResources.Employee2

select distinct e.employeeid,e.firstname,e.lastname,e.jobtitle,
m.employeeid,m.firstname,m.lastname,m.jobtitle,count(m.EmployeeID) as level
from HumanResources.Employee2 m
right join HumanResources.Employee2 e
on m.EmployeeID=e.ManagerID
group by e.employeeid,e.firstname,e.lastname,e.jobtitle,
m.employeeid,m.firstname,m.lastname,m.jobtitle





SELECT e.employeeid,e.firstname,e.lastname,e.jobtitle,
m.employeeid,m.firstname,m.lastname,m.jobtitle, LEVEL
from HumanResources.Employee2 m
START WITH m IS NULL
CONNECT BY m.EmployeeID = PRIOR e.ManagerID
ORDER SIBLINGS BY m;

WITH MYCTE
AS
(
-- Anchor member definition
    SELECT e.ManagerID, e.EmployeeID, e.Title, edh.DepartmentID, 
        0 AS Level
    FROM dbo.MyEmployees AS e
    INNER JOIN HumanResources.EmployeeDepartmentHistory AS edh
        ON e.EmployeeID = edh.BusinessEntityID AND edh.EndDate IS NULL
    WHERE ManagerID IS NULL
    UNION ALL
-- Recursive member definition
    SELECT e.ManagerID, e.EmployeeID, e.Title, edh.DepartmentID,
        Level + 1
    FROM dbo.MyEmployees AS e
    INNER JOIN HumanResources.EmployeeDepartmentHistory AS edh
        ON e.EmployeeID = edh.BusinessEntityID AND edh.EndDate IS NULL
    INNER JOIN DirectReports AS d
        ON e.ManagerID = d.EmployeeID
)
-- Statement that executes the CTE
SELECT ManagerID, EmployeeID, Title, DeptID, Level
FROM DirectReports
INNER JOIN HumanResources.Department AS dp
    ON DirectReports.DeptID = dp.DepartmentID
WHERE dp.GroupName = N'Sales and Marketing' OR Level = 0;


with MYCTE AS
( 
SELECT DISTINCT E.EmployeeID , 
					CAST(E.FirstName + ' ' + E.LastName AS NVARCHAR(MAX)) AS FullName,
					ManagerId,
					CAST('None'  AS NVARCHAR(max)) AS ManagerName,
					0 AS level 
	FROM HumanResources.Employee2 E
	Where ManagerID IS NULL
		
		UNION ALL

SELECT DISTINCT EmployeeID , 
					CAST(E.FirstName + ' ' + E.LastName AS NVARCHAR(MAX)) AS FullName,
					ManagerId,
					CAST(M.FirstName + ' '+ M.LastName  AS NVARCHAR(max)) AS ManagerName,
					(M.Level+1) AS level 
	FROM HumanResources.Employee2 E
	JOIN MYCTE M
		ON E.ManagerID= M.EmployeeID 

)
select * from MYCTE