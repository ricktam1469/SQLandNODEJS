--ProductIDs of every item sold on the first day any product was purchased from the system

SELECT Prod.ProductID
FROM Production.Product Prod
JOIN SALES.SalesOrderDetail SOD
	ON Prod.ProductID=SOD.ProductID
JOIN Sales.SalesOrderHeader SOH
	ON SOD.SalesOrderID=SOH.SalesOrderID
WHERE SOH.OrderDate=
(
SELECT MIN(OrderDate)
FROM SALES.SalesOrderHeader
)


 --List of all products with superoffers
SELECT DISTINCT Prod.ProductID
FROM Production.Product Prod
WHERE Prod.ProductID in
(
SELECT SOP.ProductID
FROM Sales.SpecialOfferProduct SOP
WHERE SOP.SpecialOfferID!=1
)

SELECT DISTINCT Prod.ProductID
FROM Production.Product Prod
JOIN Sales.SpecialOfferProduct SOP
	ON Prod.ProductID=SOP.ProductID
WHERE SOP.SpecialOfferID!=1

--List of all products without superoffers
SELECT DISTINCT Prod.ProductID
FROM Production.Product Prod
LEFT JOIN Sales.SpecialOfferProduct SOP
	ON Prod.ProductID=SOP.ProductID
WHERE SOP.SpecialOfferID IS NULL


SELECT DISTINCT Prod.ProductID
FROM Production.Product Prod
WHERE NOT EXISTS
(
SELECT 1
FROM SALES.SpecialOfferProduct SOP
WHERE SOP.ProductID=Prod.ProductID
)


--Each Color's heaviest product
SELECT Prod1.Color,Prod1.ProductID 
FROM Production.Product Prod1
WHERE Prod1.Weight=
(
SELECT Max(Prod2.Weight)
FROM Production.Product Prod2
WHERE Prod1.Color=Prod2.Color
)

--All orders placed by all customers on the day they placed their first order
SELECT c.CustomerID, soh.OrderDate,P.Name
FROM Sales.Customer c
JOIN Sales.SalesOrderHeader soh
	ON soh.CustomerID=c.CustomerID
JOIN SALES.SalesOrderDetail SOD
	ON SOD.SalesOrderID=SOH.SalesOrderID
JOIN Production.Product P
	ON P.ProductID=SOD.ProductID
WHERE soh.OrderDate=
(
SELECT MIN(soh1.orderDate)
FROM  Sales.SalesOrderHeader soh1
WHERE soh1.CustomerID=c.CustomerID
)
ORDER BY c.CustomerID

SELECT *
FROM Production.Product

-- Account number and the first date of order for all customers
SELECT  C.CustomerID,C.AccountNumber,SOH.OrderDate
FROM Sales.Customer C
JOIN Sales.SalesOrderHeader SOH
	ON SOH.CustomerID=C.CustomerID
WHERE SOH.OrderDate=
(
SELECT MIN(OrderDate)
FROM SALES.SalesOrderHeader soh1
WHERE soh1.CustomerID=c.CustomerID
)




--the account number and territory for all accounts that ordered not only an HL Mountain Rear Wheel, 
--but also an HL Mountain Front Wheel

--Using CTE 
WITH myCTE AS
(
SELECT c.CustomerID, c.AccountNumber,c.TerritoryID, st.Name,p.Name as productName
FROM Sales.Customer c
JOIN Sales.SalesOrderHeader SOH
	ON c.CustomerID=SOH.CustomerID
JOIN Sales.SalesOrderDetail SOD
	ON SOD.SalesOrderID=SOH.SalesOrderID
JOIN Production.Product p
	ON sod.ProductID=p.ProductID
JOIN Sales.SalesTerritory ST
	ON c.TerritoryID=st.TerritoryID
)
SELECT cte1.AccountNumber, cte1.CustomerID, cte1.Name, cte1.productName,cte1.TerritoryID
FROM myCTE cte1
JOIN myCTE cte2
ON cte1.CustomerID=cte2.CustomerID
WHERE cte1.productName='HL Mountain Front Wheel' AND cte2.productName='HL Mountain Rear Wheel'
 
 --Sum of OrderQty with Product Id for each product, for the orders placed on the first date it was ever bought

 select * 
 from sales.SalesOrderDetail

SELECT SUM(OrderQty),ProductID,MIN(OrderDate)
FROM(
 SELECT Prod.ProductID,SOD.OrderQty,soh.OrderDate
FROM Production.Product Prod
JOIN SALES.SalesOrderDetail SOD
	ON Prod.ProductID=SOD.ProductID
JOIN Sales.SalesOrderHeader SOH
	ON SOD.SalesOrderID=SOH.SalesOrderID
	 ) TABLE1
WHERE TABLE1.OrderDate=
(
SELECT min(soh.OrderDate)
FROM Production.Product Prod
JOIN SALES.SalesOrderDetail SOD
	ON Prod.ProductID=SOD.ProductID
JOIN Sales.SalesOrderHeader SOH
	ON SOD.SalesOrderID=SOH.SalesOrderID
WHERE PROD.ProductID=TABLE1.ProductID)
GROUP BY TABLE1.ProductID
ORDER BY TABLE1.ProductID


 



--People who are (not) employees

SELECT FirstName,LastName 
FROM Person.Person p
WHERE NOT EXISTS
(
SELECT 1
FROM HumanResources.Employee Emp
WHERE P.BusinessEntityID=Emp.BusinessEntityID
)


WITH MYCTE AS 
(
SELECT DISTINCT E.EmployeeID, 
         CAST(E.FirstName + '' +E.LastName AS nvarchar(MAX)) AS FULLNAME, 
         E.JobTitle, 
         CAST(NULL AS INT) AS MANAGERID, 
         CAST('NONE' AS nvarchar(MAX))AS MANAGERNAME, 
         0 AS LEVEL
FROM HumanResources.Employee2 E
WHERE E.ManagerID IS NULL 
UNION ALL

SELECT E.EmployeeID, 
                  CAST(E.FirstName + '' +E.LastName AS nvarchar(MAX)) AS FULLNAME, 
                  E.JobTitle, 
                  M.EmployeeID AS MANAGERID, 
                  CAST(M.FULLNAME AS nvarchar(MAX)) AS MANAGERNAME, 
                  (M.LEVEL+1) AS LEVEL
FROM HumanResources.Employee2 E
JOIN MYCTE M
               ON E.ManagerID = M.EmployeeID
)
SELECT * 
FROM MYCTE

