IF EXISTS
(
select 1 
FROM sys.views 
where name = 'PersonSales'
)
BEGIN 
	DROP VIEW Sales.PersonSales
END
GO

CREATE VIEW Sales.PersonSales
AS
SELECT C.CustomerID,SUM(TotalDue) SumTotalDue,P.LastName + ',' + P.FirstName AS NAME
FROM Person.Person P
JOIN Sales.Customer C
ON P.BusinessEntityID = C.PersonID
JOIN Sales.SalesOrderHeader H
ON C.CustomerID = H.CustomerID
GROUP BY C.CustomerID, P.LastName + ',' + P.FirstName
GO