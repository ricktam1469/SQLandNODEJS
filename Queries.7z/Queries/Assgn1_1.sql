select c.customerID from sales.Customer c
join sales.SalesOrderHeader soh
on c.customerID=soh.customerID;

select count(*) from sales.SalesOrderHeader

SELECT c.CustomerID, s.SalesOrderID, d.SalesOrderDetailID
FROM Sales.Customer c 
LEFT OUTER JOIN Sales.SalesOrderHeader s ON c.CustomerID = s.CustomerID 
LEFT OUTER JOIN Sales.SalesOrderDetail d ON s.SalesOrderID = d.SalesOrderID
WHERE s.SalesOrderID IS NULL

select c.customerID
from sales.Customer c
join sales.SalesOrderHeader soh
	on c.CustomerID=soh.CustomerID
join sales.SalesOrderDetail sod
	on sod.SalesOrderID=soh.SalesOrderID
join Production.Product p
	on p.ProductID=sod.ProductID
where EXISTS(
select p.name from production.product
)

with mycte as(
select sod.ProductID,soh.OrderDate,sum(sod.OrderQty) as Qtysold
from sales.SalesOrderHeader soh
join sales.SalesOrderDetail sod
	on sod.SalesOrderID=soh.SalesOrderID
join Production.Product p
	on p.ProductID=sod.ProductID
group by sod.ProductID,soh.OrderDate
)

select * from mycte ds1 where 
ds1




select c.customerID
from sales.Customer c
join sales.SalesOrderHeader soh
	on c.CustomerID=soh.CustomerID
join sales.SalesOrderDetail sod
	on sod.SalesOrderID=soh.SalesOrderID
join Production.Product p
	on p.ProductID=sod.ProductID