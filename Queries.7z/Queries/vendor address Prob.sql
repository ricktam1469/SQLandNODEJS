
WITH a AS (
SELECT va.VendorID, a.Address
FROM VendorAddress va
JOIN Address a
ON va.AddressID = a.AddressID
)
SELECT v.VendorName, a.Address
FROM Vendors v
LEFT JOIN a
ON v.VendorID = a.VendorID
-----
SELECT * FROM dbo.Address A 
JOIN dbo.VendorAddress VA
ON A.AddressID=VA.AddressID 
RIGHT JOIN dbo.Vendors V 
ON VA.VendorID = V.VendorID 
