SELECT *
FROM Person.Person
FOR XML RAW

SELECT *
FROM sys.columns
WHERE object_id = OBJECT_ID('Person.Person')
FOR XML PATH