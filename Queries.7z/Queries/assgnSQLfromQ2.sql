 select * from Sales.SalesOrderDetail order by OrderQty;

 --Ques 2--
SELECT c.CustomerID, s.SalesOrderID
FROM Sales.Customer c 
LEFT OUTER JOIN Sales.SalesOrderHeader s 
ON c.CustomerID = s.CustomerID
WHERE s.SalesOrderID IS NULL

WITH s AS
(   SELECT SalesOrderID, customerID
    FROM Sales.SalesOrderHeader
   
)
SELECT c.CustomerID, s.SalesOrderID
FROM Sales.Customer c 
LEFT OUTER JOIN s ON c.customerID = s.customerID
WHERE s.SalesOrderID IS NULL


select c.CustomerID
from Sales.Customer c
where not exists(
select s.SalesOrderID from Sales.SalesOrderHeader s
where s.CustomerID=c.CustomerID
)

select c.CustomerID
from Sales.Customer c
where c.CustomerID not in(
select s.CustomerID from Sales.SalesOrderHeader s
)

SELECT DISTINCT c.CustomerID
FROM Sales.Customer c
WHERE c.CustomerID NOT IN 
(
SELECT s.CustomerID
FROM sales.SalesOrderHeader s
)

SELECT DISTINCT c.CustomerID
FROM Sales.Customer c
Left Join sales.SalesOrderHeader s
	On c.CustomerID=s.CustomerID
where s.SalesOrderID
 Is NUll
 ORDER BY c.CustomerID


--Ques3--

SELECT TOP 100 ss.AccountNumbeR, ss.OrderDate			-- show the most recent 5 orders from accounts
FROM Sales.SalesOrderHeader ss
WHERE ss.AccountNumber IN (SELECT ss.AccountNumber	-- that have spent more than $70,000  
                FROM Sales.SalesOrderHeader ss
				GROUP BY ss.AccountNumber
				ORDER BY ss.TotalDue
				)
ORDER BY OrderDate DESC


WITH cte AS (
SELECT CustomerID
FROM Sales.SalesOrderHeader H
GROUP BY CustomerID
HAVING SUM(TotalDue) > 70000
), TopOrders AS (
SELECT H.CustomerID, H.SalesOrderID, H.OrderDate, H.TotalDue, ROW_NUMBER()
OVER (PARTITION BY H.CustomerID ORDER BY OrderDate DESC) OrderRow
FROM Sales.SalesOrderHeader H
JOIN cte S
ON H.CustomerID = S.CustomerID
)
SELECT CustomerID, SalesOrderID, OrderDate, TotalDue
FROM TopOrders
WHERE OrderRow <= 5
ORDER BY CustomerID, OrderRow



--Ques 5
CREATE PROC SupplNameInfo
@FirstName nvarchar(50)
AS
SELECT per.LastName, per.FirstName
FROM Person.Person per
JOIN HumanResources.Employee emp
ON per. BusinessEntityID = emp.BusinessEntityID
WHERE per.FirstName LIKE @FirstName + '%';

EXEC SupplNameInfo 'Kim';


--ques 6
DROP TRIGGER [Production].[trgLimitPriceChanges]

CREATE TRIGGER [Production].[trgLimitPriceChanges]
ON [Production].[Product]
FOR UPDATE
AS
IF EXISTS
(
SELECT *
FROM inserted i
JOIN deleted d
ON i.ProductID = d.ProductID
WHERE i.ListPrice > (d.ListPrice * 1.15)
)
BEGIN TRAN
RAISERROR('Price increase may not be greater than 15 percent.Transaction Failed.',16,1)
ROLLBACK TRAN
END
GO





--------------------------------------------------------------
--views
IF EXISTS
(
select 1 
FROM sys.views 
where name = 'PersonSales'
)
BEGIN 
	DROP VIEW Sales.PersonSales
END
GO

CREATE VIEW Sales.PersonSales
AS
SELECT C.CustomerID,SUM(TotalDue) SumTotalDue,P.LastName + ',' + P.FirstName AS NAME
FROM Person.Person P
JOIN Sales.Customer C
ON P.BusinessEntityID = C.PersonID
JOIN Sales.SalesOrderHeader H
ON C.CustomerID = H.CustomerID
GROUP BY C.CustomerID, P.LastName + ',' + P.FirstName
GO


