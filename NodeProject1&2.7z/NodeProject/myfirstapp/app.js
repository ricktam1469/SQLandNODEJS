////express////////////
var express = require('express');
var app = express();
app.use(express.static('public'));
//////body parser//////
var bp = require('body-parser');
//////JSON Reader//////
var fs= require('fs');
//////MSSQL Package///////
var sql=require('mssql');
//////Request Package/////
var request = require('request');

//////////////Config Var//////////////////////////////
var config = {
    user: 'sa',
    password: 'Passw0rd',
    server: 'localhost', // You can use 'localhost\\instance' to connect to named instance 
    database: 'NodeDemos',
    options:{
        instanceName: 'SQLEXPRESS'
    }
 };
///////////////////////////////////////////////////////
app.use(bp.urlencoded({
    extended: true
}));

/////////////////////////GET FROM JSON//////////////////////////////////////////////////////
app.get('/Users',function(req,res){
fs.readFile('data/user.json', function (err,data) {
  res.send(JSON.parse(data));
});

});
////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////POST FROM JSON//////////////////////////////////////////////////////
app.post('/Users', function (req, res) {
    
    fs.readFile('data/user.json', function (err, data) {
        console.log(JSON.parse(data));
        var obj = JSON.parse(data);
        obj.push(req.body);
        fs.writeFile('data/Users.json', JSON.stringify(obj), function (err, data) {
            res.send(true);
        });
        
    });
    console.log('body: ' + JSON.stringify(req.body));
    
});
////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////PUT FROM JSON//////////////////////////////////////////////////////
app.put('/Users', function (req, res) {
    fs.readFile('data/user.json', function (err, data) {
        console.log(JSON.parse(data));
        var obj = JSON.parse(data);
        var idRec = parseInt(req.body.id);
        var index = obj.findIndex(function (user) {
            return parseInt(user.id) === idRec;
        });
        console.log(index);
        obj.splice(index, 1,req.body);
        fs.writeFile('data/user.json', JSON.stringify(obj), function (err, data) {
            res.send(req.body);
        });

    });
    console.log('body: ' + JSON.stringify(req.body));
});
///////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////DELETE FROM JSON//////////////////////////////////////////////////////
app.delete('/Users', function (req, res) {
    

    fs.readFile('data/user.json', function (err, data) {
        console.log(JSON.parse(data));
        var obj = JSON.parse(data);
        var idRec = parseInt(req.body.id);
        var index=obj.findIndex(function (user) {
         return  parseInt( user.id) === idRec;
        });
        console.log(index);
       obj.splice(index, 1);
       fs.writeFile('data/user.json', JSON.stringify(obj), function (err, data) {
            res.send(true)
        });

    });
    console.log('body: ' + JSON.stringify(req.body));
});

/////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////GET FROM MSSQL//////////////////////////////////////////////////////
app.get('/Users-sql',function(req,res){
    sql.connect(config).then(function() {
        // Query 
        var sqlRequest=new sql.Request();
       sqlRequest.query('select * from [User]').then(function(recordset) {
             res.send(JSON.parse(JSON.stringify(recordset)));
        }).catch(function(err) {
            console.log(err);
        });
     
        
    }).catch(function(err) {
        // ... error checks 
    });

});
//////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////POST FROM MSSQL//////////////////////////////////////////////////////
app.post('/Users-sql', function (req, res) {
    
    fs.readFile('data/user.json', function (err, data) {
        console.log(JSON.parse(data));
        var obj = JSON.parse(data);
        obj.push(req.body);
        fs.writeFile('data/Users.json', JSON.stringify(obj), function (err, data) {
            res.send(true);
        });
        
    });
    console.log('body: ' + JSON.stringify(req.body));
    
});
/////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////PUT FROM MSSQL//////////////////////////////////////////////////////
app.put('/Users-sql', function (req, res) {
    fs.readFile('data/user.json', function (err, data) {
        console.log(JSON.parse(data));
        var obj = JSON.parse(data);
        var idRec = parseInt(req.body.id);
        var index = obj.findIndex(function (user) {
            return parseInt(user.id) === idRec;
        });
        console.log(index);
        obj.splice(index, 1,req.body);
        fs.writeFile('data/user.json', JSON.stringify(obj), function (err, data) {
            res.send(req.body);
        });

    });
    console.log('body: ' + JSON.stringify(req.body));
});
////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////DELETE FROM MSSQL//////////////////////////////////////////////////////
app.delete('/Users-sql', function (req, res) {
    

    fs.readFile('data/user.json', function (err, data) {
        console.log(JSON.parse(data));
        var obj = JSON.parse(data);
        var idRec = parseInt(req.body.id);
        var index=obj.findIndex(function (user) {
         return  parseInt( user.id) === idRec;
        });
        console.log(index);
       obj.splice(index, 1);
       fs.writeFile('data/user.json', JSON.stringify(obj), function (err, data) {
            res.send(true)
        });

    });
    console.log('body: ' + JSON.stringify(req.body));
});

//////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////DOWNLOAD EXAMPLE//////////////////////////////////////////////////////
var download = function(uri, filename, callback){
  request.head(uri, function(err, res, body){
    console.log('content-type:', res.headers['content-type']);
    console.log('content-length:', res.headers['content-length']);

    request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
  });
};

download('https://www.google.com/images/srpr/logo3w.png', 'google.png', function(){
  console.log('done');
});
///////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////LISTNING POST//////////////////////////////////////////////////////
app.listen(3000, function () {
  console.log('Ricktam App started and listening on port 3000!');
});